package com.parallel.spring.exceptions;



public class InvalidAmountException extends Exception{
public InvalidAmountException(String string)
{
	super(string);
}
}
