package com.parallel.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringParallelProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringParallelProjectApplication.class, args);
	}

}
